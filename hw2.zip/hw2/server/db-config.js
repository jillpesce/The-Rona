// Private. Will not be included in submission
module.exports = {
  host: "fling.seas.upenn.edu",
  user: "<username>",
  password: "<password>",
  database: "<username>"
};
